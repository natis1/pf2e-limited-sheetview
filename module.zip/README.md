# FoundryVTT Pf2e Limited Sheetview

This module makes it so that you can see people's complete sheets when the actor visibility is set to limited, but disallows you seeing their vision.
